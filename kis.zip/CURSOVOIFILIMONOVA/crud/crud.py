from sqlalchemy.orm import Session
from models import Student, Debt, Schedule
import schemas  # Импортируем схемы напрямую
from datetime import datetime

def create_student(db: Session, student: schemas.StudentCreate):
    db_student = Student(**student.dict())
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student

def get_student(db: Session, student_id: int):
    return db.query(Student).filter(Student.id == student_id).first()

def get_students(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Student).offset(skip).limit(limit).all()

def update_student(db: Session, student_id: int, student: schemas.StudentCreate):
    db_student = get_student(db, student_id)
    if not db_student:
        return None
    for key, value in student.dict().items():
        setattr(db_student, key, value)
    db.commit()
    db.refresh(db_student)
    return db_student

def delete_student(db: Session, student_id: int):
    db_student = get_student(db, student_id)
    if not db_student:
        return False
    db.delete(db_student)
    db.commit()
    return True

def create_debt(db: Session, debt: schemas.DebtCreate):
    student = get_student(db, debt.student_id)
    if not student:
        return None
    db_debt = Debt(**debt.dict())
    db.add(db_debt)
    db.commit()
    db.refresh(db_debt)
    return db_debt

def get_debts(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Debt).offset(skip).limit(limit).all()

def get_student_debts(db: Session, student_id: int):
    return db.query(Debt).filter(Debt.student_id == student_id).all()

def update_debt(db: Session, debt_id: int, debt: schemas.DebtCreate):
    db_debt = db.query(Debt).filter(Debt.id == debt_id).first()
    if not db_debt:
        return None
    for key, value in debt.dict().items():
        setattr(db_debt, key, value)
    db.commit()
    db.refresh(db_debt)
    return db_debt

def delete_debt(db: Session, debt_id: int):
    db_debt = db.query(Debt).filter(Debt.id == debt_id).first()
    if not db_debt:
        return False
    db.delete(db_debt)
    db.commit()
    return True

def pay_debt(db: Session, debt_id: int):
    debt = db.query(Debt).filter(Debt.id == debt_id).first()
    if not debt:
        return None
    debt.status = "погашена"
    db.commit()
    db.refresh(debt)
    return debt

def create_schedule(db: Session, schedule: schemas.ScheduleCreate):
    debt = db.query(Debt).filter(Debt.id == schedule.debt_id).first()
    if not debt:
        return None
    if debt.status != "активна":
        return None
    db_schedule = Schedule(**schedule.dict())
    db.add(db_schedule)
    db.commit()
    db.refresh(db_schedule)
    return db_schedule

def get_schedules(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Schedule).offset(skip).limit(limit).all()

def update_schedule(db: Session, schedule_id: int, schedule: schemas.ScheduleCreate):
    db_schedule = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not db_schedule:
        return None
    for key, value in schedule.dict().items():
        setattr(db_schedule, key, value)
    db.commit()
    db.refresh(db_schedule)
    return db_schedule

def delete_schedule(db: Session, schedule_id: int):
    db_schedule = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not db_schedule:
        return False
    db.delete(db_schedule)
    db.commit()
    return True